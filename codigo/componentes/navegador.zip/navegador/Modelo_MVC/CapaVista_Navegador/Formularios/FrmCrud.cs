﻿using CapaVista_Navegador.formularios;
using System;
using System.Windows.Forms;

namespace CapaVista_Navegador
{
    public partial class FrmCrud : Form
    {
        // CAMBIAR AQUÍ MANUALMENTE LA TABLA A LA QUE SE DESEA HACER CRUD
        private string _NombreTabla = "tbl_empleados";

        private ClsCrudEventos _Eventos;

        public string NombreTabla
        {
            get { return _NombreTabla; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    _NombreTabla = value.Trim();

                    if (_Eventos != null)
                    {
                        _Eventos.NavegadorMetConsultar();
                    }
                }
            }
        }

        public FrmCrud()
            : this("USUARIO_PRUEBA", "EMPLEADOS", null)
        {
        }

        public FrmCrud(string UsuarioActual, string CodigoModulo)
            : this(UsuarioActual, CodigoModulo, null)
        {
        }

        public FrmCrud(
            string UsuarioActual,
            string CodigoModulo,
            string Tabla)
        {
            InitializeComponent();

            if (!string.IsNullOrWhiteSpace(Tabla))
            {
                _NombreTabla = Tabla.Trim();
            }

            _Eventos = new ClsCrudEventos(
                this,
                UsuarioActual,
                CodigoModulo);

            NavegadorMetCablearBotones();

            Load += (Origen, Evento) =>
                _Eventos.NavegadorMetCargar();

            Resize += (Origen, Evento) =>
                _Eventos.NavegadorMetPosicionar();
        }

        private void NavegadorMetCablearBotones()
        {
            NavegadorBtnIngresar.Click += NavegadorMetIngresarClick;
            NavegadorBtnCancelar.Click += NavegadorMetCancelarClick;
            NavegadorBtnConsultar.Click += NavegadorMetConsultarClick;
            NavegadorBtnRefrescar.Click += NavegadorMetRefrescarClick;
            NavegadorBtnModificar.Click += NavegadorMetModificarClick;
            NavegadorBtnEliminar.Click += NavegadorMetEliminarClick;
            NavegadorBtnGuardar.Click += NavegadorMetGuardarClick;

            NavegadorBtnSalir.Click +=
                (Origen, Evento) => Close();

            NavegadorBtnInicio.Click +=
                (Origen, Evento) => _Eventos.NavegadorMetInicio();

            NavegadorBtnAnterior.Click +=
                (Origen, Evento) => _Eventos.NavegadorMetAnterior();

            NavegadorBtnSiguiente.Click +=
                (Origen, Evento) => _Eventos.NavegadorMetSiguiente();

            NavegadorBtnFin.Click +=
                (Origen, Evento) => _Eventos.NavegadorMetFin();
        }

        private void NavegadorMetIngresarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetIngresar();
        }

        private void NavegadorMetConsultarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetConsultar();
        }

        private void NavegadorMetRefrescarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetRefrescar();
        }

        private void NavegadorMetModificarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetModificar();
        }

        private void NavegadorMetEliminarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetEliminar();
        }

        private void NavegadorMetGuardarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetGuardar();
        }

        private void NavegadorMetCancelarClick(
            object Sender,
            EventArgs Evento)
        {
            _Eventos.NavegadorMetCancelar();
        }
    }
}